package com.example.labwakenet;

import android.os.Bundle;
import android.widget.*;
import androidx.appcompat.app.AppCompatActivity;

import java.net.InetSocketAddress;
import java.net.Socket;
import java.util.*;

public class CheckPcsActivity extends AppCompatActivity {

    ListView statusListView;
    List<String> statusList = new ArrayList<>();
    ArrayAdapter<String> adapter;

    Map<String, String> pcIpMap = new HashMap<String, String>() {{
        put("PRPC01", "192.168.88.2"); put("PRPC02", "192.168.88.3"); put("PRPC03", "192.168.88.4");
        put("PRPC04", "192.168.88.5"); put("PRPC05", "192.168.88.6"); put("PRPC06", "192.168.88.7");
        put("PRPC07", "192.168.88.8"); put("PRPC08", "192.168.88.9"); put("PRPC09", "192.168.88.10");
        put("PRPC10", "192.168.88.11"); put("PRPC11", "192.168.88.12"); put("PRPC12", "192.168.88.13");
        put("PRPC13", "192.168.88.14"); put("PRPC14", "192.168.88.15"); put("PRPC15", "192.168.88.16");
        put("PRPC16", "192.168.88.17"); put("PRPC17", "192.168.88.18"); put("PRPC18", "192.168.88.19");
        put("PRPC19", "192.168.88.20"); put("PRPC20", "192.168.88.21"); put("PRPC21", "192.168.88.22");
        put("PRPC22", "192.168.88.23"); put("PRPC23", "192.168.88.24"); put("PRPC24", "192.168.88.25");
        put("PRPC25", "192.168.88.26"); put("PRPC26", "192.168.88.27"); put("PRPC27DESK", "192.168.88.28");
    }};

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_check_pcs);

        statusListView = findViewById(R.id.statusListView);
        adapter = new ArrayAdapter<>(this, android.R.layout.simple_list_item_1, statusList);
        statusListView.setAdapter(adapter);

        checkAllPcs();
    }

    private void checkAllPcs() {
        new Thread(() -> {
            List<String> sortedKeys = new ArrayList<>(pcIpMap.keySet());
            Collections.sort(sortedKeys, Comparator.comparing(k -> k.replaceAll("[^0-9]", ""), String::compareTo));

            for (String name : sortedKeys) {
                String ip = pcIpMap.get(name);
                boolean online = isReachable(ip, 41007, 300);
                String status = name + " (" + ip + "): " + (online ? "🟢 Online" : "🔴 Offline");

                runOnUiThread(() -> {
                    statusList.add(status);
                    adapter.notifyDataSetChanged();
                });
            }
        }).start();
    }

    private boolean isReachable(String ip, int port, int timeout) {
        try (Socket socket = new Socket()) {
            socket.connect(new InetSocketAddress(ip, port), timeout);
            return true;
        } catch (Exception e) {
            return false;
        }
    }
}
