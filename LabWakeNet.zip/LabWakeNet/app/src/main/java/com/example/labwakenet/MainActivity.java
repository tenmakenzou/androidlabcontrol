package com.example.labwakenet;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.os.Bundle;
import android.widget.*;
import androidx.appcompat.app.AppCompatActivity;

import java.net.UnknownHostException;
import java.util.HashMap;
import java.util.Map;

public class MainActivity extends AppCompatActivity {

    Spinner pcs, commands;
    Button checkPcsButton, sendButton, wolButton;
    TextView resultTextView;

    String[] commandsArray = {"Echo", "Restart", "Shutdown", "Restore"};
    String[] pcsArray = new String[27];
    Map<String, String> pcIpMap = new HashMap<>();

    @SuppressLint("DefaultLocale")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        for (int i = 0; i < pcsArray.length; i++) {
            pcsArray[i] = String.format("PRPC%02d", i + 1);
        }
        pcsArray[26] = "PRPC27DESK";

        String[] ips = {
                "192.168.88.2", "192.168.88.3", "192.168.88.4", "192.168.88.5", "192.168.88.6",
                "192.168.88.7", "192.168.88.8", "192.168.88.9", "192.168.88.10", "192.168.88.11",
                "192.168.88.12", "192.168.88.13", "192.168.88.14", "192.168.88.15", "192.168.88.16",
                "192.168.88.17", "192.168.88.18", "192.168.88.19", "192.168.88.20", "192.168.88.21",
                "192.168.88.22", "192.168.88.23", "192.168.88.24", "192.168.88.25", "192.168.88.26",
                "192.168.88.27", "192.168.88.28"
        };

        for (int i = 0; i < pcsArray.length; i++) {
            pcIpMap.put(pcsArray[i], ips[i]);
        }

        pcs = findViewById(R.id.pcs);
        commands = findViewById(R.id.commands);
        sendButton = findViewById(R.id.sendButton);
        wolButton = findViewById(R.id.wolButton);
        checkPcsButton = findViewById(R.id.checkPcsButton);
        resultTextView = findViewById(R.id.resultTextView);

        pcs.setAdapter(new ArrayAdapter<>(this, android.R.layout.simple_spinner_dropdown_item, pcsArray));
        commands.setAdapter(new ArrayAdapter<>(this, android.R.layout.simple_spinner_dropdown_item, commandsArray));

        sendButton.setOnClickListener(v -> sendCommand());
        wolButton.setOnClickListener(v -> sendWOL());
        checkPcsButton.setOnClickListener(v -> startActivity(new Intent(this, CheckPcsActivity.class)));
    }

    @SuppressLint("SetTextI18n")
    private void sendCommand() {
        String target = pcs.getSelectedItem().toString();
        String command = commands.getSelectedItem().toString();
        String ip = pcIpMap.get(target);

        if (ip == null) {
            resultTextView.setText("Error: Unknown PC selected (" + target + ")");
            return;
        }

        new Thread(() -> {
            try {
                String result = TcpClient.sendCommand(ip, 41007, command);
                runOnUiThread(() -> resultTextView.setText(result));
            } catch (UnknownHostException e) {
                runOnUiThread(() -> resultTextView.setText("Error: Unable to resolve host " + ip));
            } catch (java.net.ConnectException e) {
                runOnUiThread(() -> resultTextView.setText("Error: Unable to connect to " + ip));
            } catch (java.net.SocketTimeoutException e) {
                runOnUiThread(() -> resultTextView.setText("Error: Connection to " + ip + " timed out"));
            } catch (Exception e) {
                runOnUiThread(() -> resultTextView.setText("Unexpected Error: " + e.getMessage()));
            }
        }).start();
    }

    @SuppressLint("SetTextI18n")
    private void sendWOL() {
        Map<String, String> macMap = new HashMap<String, String>() {{
            put("PRPC01", "50:81:40:2B:91:8D"); put("PRPC02", "50:81:40:2B:7C:78");
            put("PRPC03", "50:81:40:2B:78:DD"); put("PRPC04", "50:81:40:2B:7B:3D");
            put("PRPC05", "50:81:40:2B:79:91"); put("PRPC06", "C8:5A:CF:0F:76:3D");
            put("PRPC07", "C8:5A:CF:0D:71:24"); put("PRPC08", "C8:5A:CF:0F:B3:FF");
            put("PRPC09", "C8:5A:CF:0E:2C:C4"); put("PRPC10", "C8:5A:CF:0F:7C:D0");
            put("PRPC11", "C8:5A:CF:0D:71:3A"); put("PRPC12", "C8:5A:CF:0F:EE:01");
            put("PRPC13", "C8:5A:CF:0E:1D:88"); put("PRPC14", "C8:5A:CF:0F:F0:1E");
            put("PRPC15", "50:81:40:2B:7D:A4"); put("PRPC16", "C8:5A:CF:0E:2C:78");
            put("PRPC17", "50:81:40:2B:87:F4"); put("PRPC18", "C8:5A:CF:0F:EC:11");
            put("PRPC19", "C8:5A:CF:0F:7C:1F"); put("PRPC20", "C8:5A:CF:0D:71:2C");
            put("PRPC21", "C8:5A:CF:0D:70:95"); put("PRPC22", "50:81:40:2B:5F:D0");
            put("PRPC23", "50:81:40:2B:7A:0B"); put("PRPC24", "50:81:40:2B:8F:D3");
            put("PRPC25", "50:81:40:2B:72:E0"); put("PRPC26", "50:81:40:2B:7A:74");
            put("PRPC27DESK", "C8:5A:CF:0F:7C:D4");
        }};

        String target = pcs.getSelectedItem().toString();
        String macAddress = macMap.get(target);

        if (macAddress == null) {
            resultTextView.setText("MAC address not found for " + target);
            return;
        }

        new Thread(() -> {
            try {
                WakeOnLan.sendWOL(macAddress, "255.255.255.255");
                runOnUiThread(() -> resultTextView.setText("WOL sent to " + target));
            } catch (Exception e) {
                runOnUiThread(() -> resultTextView.setText("WOL Error: " + e.getMessage()));
            }
        }).start();
    }
}
