package com.example.labwakenet;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.os.Bundle;
import android.widget.*;
import androidx.appcompat.app.AppCompatActivity;

import java.net.UnknownHostException;
import java.util.HashMap;
import java.util.Map;

public class MainActivity extends AppCompatActivity {

    Spinner pcs;
    Spinner commands;
    Button checkPcsButton;
    Button sendButton, wolButton;
    TextView resultTextView;

    String[] commandsArray = {"Echo", "Restart", "Shutdown", "Restore"};
    String[] pcsArray = new String[27];
    Map<String, String> pcIpMap = new HashMap<>();

    @SuppressLint("DefaultLocale")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        // Create PC list
        for (int i = 0; i < pcsArray.length; i++) {
            pcsArray[i] = String.format("PRPC%02d", i + 1);
        }

        // Add mappings: Replace with real IPs
        pcIpMap.put("PRPC01", "192.168.88.2");
        pcIpMap.put("PRPC02", "192.168.88.3");
        pcIpMap.put("PRPC03", "192.168.88.4");
        pcIpMap.put("PRPC04", "192.168.88.5");
        pcIpMap.put("PRPC05", "192.168.88.6");
        pcIpMap.put("PRPC06", "192.168.88.7");
        pcIpMap.put("PRPC07", "192.168.88.8");
        pcIpMap.put("PRPC08", "192.168.88.9");
        pcIpMap.put("PRPC09", "192.168.88.10");
        pcIpMap.put("PRPC10", "192.168.88.11");
        pcIpMap.put("PRPC11", "192.168.88.12");
        pcIpMap.put("PRPC12", "192.168.88.13");
        pcIpMap.put("PRPC13", "192.168.88.14");
        pcIpMap.put("PRPC14", "192.168.88.15");
        pcIpMap.put("PRPC15", "192.168.88.16");
        pcIpMap.put("PRPC16", "192.168.88.17");
        pcIpMap.put("PRPC17", "192.168.88.18");
        pcIpMap.put("PRPC18", "192.168.88.19");
        pcIpMap.put("PRPC19", "192.168.88.20");
        pcIpMap.put("PRPC20", "192.168.88.21");
        pcIpMap.put("PRPC21", "192.168.88.22");
        pcIpMap.put("PRPC22", "192.168.88.23");
        pcIpMap.put("PRPC23", "192.168.88.24");
        pcIpMap.put("PRPC24", "192.168.88.25");
        pcIpMap.put("PRPC25", "192.168.88.26");
        pcIpMap.put("PRPC26", "192.168.88.27");
        pcIpMap.put("PRPC27DESK", "192.168.88.28");


        commands = findViewById(R.id.commands);
        pcs = findViewById(R.id.pcs);
        sendButton = findViewById(R.id.sendButton);
        wolButton = findViewById(R.id.wolButton);
        checkPcsButton = findViewById(R.id.checkPcsButton);
        resultTextView = findViewById(R.id.resultTextView);

        ArrayAdapter<String> adapterCommands = new ArrayAdapter<>(this, android.R.layout.simple_spinner_dropdown_item, commandsArray);
        commands.setAdapter(adapterCommands);

        ArrayAdapter<String> adapterPcs = new ArrayAdapter<>(this, android.R.layout.simple_spinner_dropdown_item, pcsArray);
        pcs.setAdapter(adapterPcs);

        checkPcsButton.setOnClickListener(v -> {
            Intent intent = new Intent(MainActivity.this, CheckPcsActivity.class);
            startActivity(intent);
        });

        sendButton.setOnClickListener(v -> sendCommand());
        wolButton.setOnClickListener(v -> sendWOL());
    }

    @SuppressLint("SetTextI18n")
    private void sendCommand() {
        String command = commands.getSelectedItem().toString();
        String target = pcs.getSelectedItem().toString();

        String ip = pcIpMap.get(target);
        if (ip == null) {
            resultTextView.setText("Error: Unknown PC selected (" + target + ")");
            return;
        }

        new Thread(() -> {
            try {
                String result = TcpClient.sendCommand(ip, 41007, command);
                runOnUiThread(() -> resultTextView.setText(result));
            } catch (UnknownHostException e) {
                runOnUiThread(() -> resultTextView.setText("Error: Unable to resolve host " + ip));
            } catch (java.net.ConnectException e) {
                runOnUiThread(() -> resultTextView.setText("Error: Unable to connect to " + ip + ":41007"));
            } catch (java.net.SocketTimeoutException e) {
                runOnUiThread(() -> resultTextView.setText("Error: Connection to " + ip + " timed out"));
            } catch (Exception e) {
                runOnUiThread(() -> resultTextView.setText("Unexpected Error: " + e.getMessage()));
            }
        }).start();
    }

    @SuppressLint("SetTextI18n")
    private void sendWOL() {
        String target = pcs.getSelectedItem().toString();


        Map<String, String> macMap = new HashMap<>();
        macMap.put("PRPC01", "50:81:40:2B:91:8D");
        macMap.put("PRPC02", "50:81:40:2B:7C:78");
        macMap.put("PRPC03", "50:81:40:2B:78:DD");
        macMap.put("PRPC04", "50:81:40:2B:7B:3D");
        macMap.put("PRPC05", "50:81:40:2B:79:91");
        macMap.put("PRPC06", "C8:5A:CF:0F:76:3D");
        macMap.put("PRPC07", "C8:5A:CF:0D:71:24");
        macMap.put("PRPC08", "C8:5A:CF:0F:B3:FF");
        macMap.put("PRPC09", "C8:5A:CF:0E:2C:C4");
        macMap.put("PRPC10", "C8:5A:CF:0F:7C:D0");
        macMap.put("PRPC11", "C8:5A:CF:0D:71:3A");
        macMap.put("PRPC12", "C8:5A:CF:0F:EE:01");
        macMap.put("PRPC13", "C8:5A:CF:0E:1D:88");
        macMap.put("PRPC14", "C8:5A:CF:0F:F0:1E");
        macMap.put("PRPC15", "50:81:40:2B:7D:A4");
        macMap.put("PRPC16", "C8:5A:CF:0E:2C:78");
        macMap.put("PRPC17", "50:81:40:2B:87:F4");
        macMap.put("PRPC18", "C8:5A:CF:0F:EC:11");
        macMap.put("PRPC19", "C8:5A:CF:0F:7C:1F");
        macMap.put("PRPC20", "C8:5A:CF:0D:71:2C");
        macMap.put("PRPC21", "C8:5A:CF:0D:70:95");
        macMap.put("PRPC22", "50:81:40:2B:5F:D0");
        macMap.put("PRPC23", "50:81:40:2B:7A:0B");
        macMap.put("PRPC24", "50:81:40:2B:8F:D3");
        macMap.put("PRPC25", "50:81:40:2B:72:E0");
        macMap.put("PRPC26", "50:81:40:2B:7A:74");
        macMap.put("PRPC27DESK", "C8:5A:CF:0F:7C:D4");

        String macAddress = macMap.get(target);
        if (macAddress == null) {
            resultTextView.setText("MAC address not found for " + target);
            return;
        }

        new Thread(() -> {
            try {
                WakeOnLan.sendWOL(macAddress, "255.255.255.255");
                runOnUiThread(() -> resultTextView.setText("WOL sent to " + target));
            } catch (Exception e) {
                runOnUiThread(() -> resultTextView.setText("WOL Error: " + e.getMessage()));
            }
        }).start();
    }
}
